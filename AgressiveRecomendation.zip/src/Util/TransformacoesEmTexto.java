/*
    Realiza o tratamento das palavras de cada Item
 */
package Util;


import Dominio.Item;
import java.text.Normalizer;

/**
 *
 * @author Marlon Miranda
 */
public class TransformacoesEmTexto {

    
    //Recebe a coluna do comentario e id do comentário e cria um documento
    public static void CriaRepresentacao(Item i) {

        String array[] = new String[i.getTexto().length()];
        array = i.getTexto().split(" ");
        
        insereNoDocumento(array, i);
    }
    

    private static void insereNoDocumento(String[] array, Item item) {

        
        
        for (int i = 0; i < array.length; i++) {
            String palavraTratada = formatString(removeProntuacao(array[i].toUpperCase()));
            if (palavraTratada.length() >= 1) {
                item.addTermo(palavraTratada);
            }
        }
        
        
    }
    
    public static  String formatString(String s) {
        
         return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        
    }
    
    

    private static String removeProntuacao(String palavra) {
        String replace = palavra.replace(",", "");
        String replace2 = replace.replace(".", "");
        String replace3 = replace2.replace(":", "");
        String replace4 = replace3.replace(";", "");
        String replace5 = replace4.replace("!", "");
        String replace6 = replace5.replace("\"", "");
        String replace7 = replace6.replace("?", "");
        String replace8 = replace7.replaceAll("\\d", "");
        String replace9 = replace8.replaceAll("[()]", "");
        String replace10 = replace9.replaceAll("", "");

        return replace10;
    }
}
