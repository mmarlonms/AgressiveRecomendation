/*
    Escreve os Resultados e métricas obtidos
 */
package Util;

import Dominio.Hating;
import Dominio.Item;
import Dominio.Palavra;
import Dominio.PrecisaoRevocacao;
import Dominio.TfIdf;
import Dominio.Usuario;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 */
public class Impressora {

    boolean teste = false;
    boolean teste2 = false;

    //##########################  Usuário ##########################//
    public void ImprimeMetricasUsuario(List<Usuario> usuarios) {

        EscritorDeArquivos metricas = new EscritorDeArquivos("Metricas//Usuario//metricas.csv");
        metricas.Gravar("Usuário;MAE;MSE;MAPE;RMSE;MAP;F1");

        for (Usuario u : usuarios) {

            metricas.Gravar(u.getCodigo() + ";" + u.getMAE() + ";" + u.getMSE() + ";" + u.getMAPE() + ";" + u.getRMSE() + ";" + u.getMap() + ";" + u.getF1());
        }

        metricas.FechaEscrita();

    }

    public void ImprimeItensRelevantesUsuario(List<Hating> hatings) {
        EscritorDeArquivos relevantes = new EscritorDeArquivos("Predicoes//Usuario//" + hatings.get(0).getCodUsuario() + "_IntensRelevantes.csv");
        for (Hating h : hatings) {
            relevantes.Gravar(h.getcodItem());
        }
        relevantes.FechaEscrita();

    }

    public void ImpreimeSimilaridadeUsuario(List<Usuario> knn, String codigoUsuario, String codigoItem) {
        EscritorDeArquivos similaridade = new EscritorDeArquivos("Predicoes//Usuario//" + codigoUsuario + "_Similaridade.csv", true);

        similaridade.Gravar("Item;Usuario;Similaridade");
        for (Usuario u : knn) {
            similaridade.Gravar(codigoItem + ";" + u.getCodigo() + ";" + u.getSimilaridade());
        }
        similaridade.FechaEscrita();
    }

    public void ImprimirRankingUsuarioItem(Usuario u) {
        EscritorDeArquivos recomendacoes = new EscritorDeArquivos("Predicoes//Usuario//" + u.getCodigo() + "_resultRankUsuarioItem.csv");

        for (Hating h : u.getHatingCalculado()) {
            recomendacoes.Gravar(h.getcodItem() + ":" + h.getHating());
        }

        recomendacoes.FechaEscrita();
    }

    public void ImprimirComparacaoPredicaoUsuario(Usuario u) {

        EscritorDeArquivos compracao = new EscritorDeArquivos("Predicoes//Usuario//" + u.getCodigo() + "_comparacaoPrecicaoUsuario.csv");

        for (Hating h : u.getHatingCalculado()) {

            for (Hating h2 : u.getHatings()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    compracao.Gravar(h.getcodItem() + " : " + h.getHating() + " : " + h2.getHating());
                }
            }

        }
        compracao.FechaEscrita();
    }

    public void ImprimePrecisaoERevocaoUsuario(List<PrecisaoRevocacao> prereovc, String codigoUsuario) {
        EscritorDeArquivos precisaoRevocacao = new EscritorDeArquivos("Predicoes//Usuario//" + codigoUsuario + "_PrecisaoRevocacao.csv");
        precisaoRevocacao.Gravar("Item;Revocacao;Precisao");

        for (PrecisaoRevocacao pr : prereovc) {
            precisaoRevocacao.Gravar(pr.getItem() + ";" + pr.getRevocacao() + ";" + pr.getPrecisao());
        }
        precisaoRevocacao.FechaEscrita();
    }

    //##########################  Item ##########################//
    public void ImpreimeSimilaridadeItem(List<Item> knn, String codigoItem, String codigoUsuario) {

        EscritorDeArquivos similaridade = new EscritorDeArquivos("Predicoes//Item//" + codigoItem + "_Similaridade.csv", true);
        similaridade.Gravar("Usario;Item;Similaridade");

        for (Item i : knn) {
            similaridade.Gravar(codigoUsuario + ";" + i.getCodigo() + ";" + i.getSimilaridade());
        }
        similaridade.FechaEscrita();
    }

    public void ImprimirRankingItemUsuario(Item i) {
        EscritorDeArquivos recomendacoes = new EscritorDeArquivos("Predicoes//Item//" + i.getCodigo() + "_resultRankItemUsuario.csv");

        for (Hating h : i.getHatingCalculado()) {
            recomendacoes.Gravar(h.getCodUsuario() + ":" + h.getHating());
        }

        recomendacoes.FechaEscrita();

    }

    public void ImprimirComparacaoPredicaoItem(Item u) {

        EscritorDeArquivos comparacao = new EscritorDeArquivos("Predicoes//Item//" + u.getCodigo() + "_comparacaoPrecicaoItem.csv");

        for (Hating h : u.getHatingCalculado()) {

            for (Hating h2 : u.getHatings()) {
                if (h2.getCodUsuario().equals(h.getCodUsuario())) {
                    comparacao.Gravar(h.getCodUsuario() + " : " + h.getHating() + " : " + h2.getHating());
                }
            }

        }
        comparacao.FechaEscrita();
    }

    public void ImprimeMetricasItem(List<Item> itens) {

        EscritorDeArquivos metricas = new EscritorDeArquivos("Metricas//Item//metricas.csv");
        metricas.Gravar("Item;MAE;MSE;MAPE;RMSE;MAP;F1");

        for (Item i : itens) {

            metricas.Gravar(i.getCodigo() + ";" + i.getMAE() + ";" + i.getMSE() + ";" + i.getMAPE() + ";" + i.getRMSE() + ";" + i.getMap() + ";" + i.getF1());
        }

        metricas.FechaEscrita();

    }

    public void ImprimePrecisaoERevocaoItem(List<PrecisaoRevocacao> prereovc, String codigoItem) {
        EscritorDeArquivos precisaoRevocacao = new EscritorDeArquivos("Predicoes//Item//" + codigoItem + "_PrecisaoRevocacao.csv");
        precisaoRevocacao.Gravar("Revocacao;Precisao");

        for (PrecisaoRevocacao pr : prereovc) {
            precisaoRevocacao.Gravar(pr.getRevocacao() + ";" + pr.getPrecisao());
        }
        precisaoRevocacao.FechaEscrita();
    }

    //##########################  Não Personalisado ##########################//
    public void ImprimeRankingHatingNaoPersonalizadoFULL(List<Hating> itens) {
        EscritorDeArquivos naoPersonalisasdo = new EscritorDeArquivos("Predicoes//Nao Personalisado//itensNaoPersonalisados.csv");

        for (Hating h : itens) {
            naoPersonalisasdo.Gravar(h.getcodItem() + ";" + h.getHating());
        }
        naoPersonalisasdo.FechaEscrita();
    }

    public void ImprimePrecisaoERevocaoNaoPersonalisado(List<PrecisaoRevocacao> prereovc, String codigoItem) {
        EscritorDeArquivos precisaoRevocacao = new EscritorDeArquivos("Predicoes//Nao Personalisado//" + codigoItem + "_PrecisaoRevocacao.csv");

        precisaoRevocacao.Gravar("Item;Revocacao;Precisao");

        for (PrecisaoRevocacao pr : prereovc) {
            precisaoRevocacao.Gravar(pr.getItem() + ";" + pr.getRevocacao() + ";" + pr.getPrecisao());
        }
        precisaoRevocacao.FechaEscrita();
    }

    public void ImprimirComparacaoPredicaoNaoPersonalisado(Usuario u) {

        EscritorDeArquivos compracao = new EscritorDeArquivos("Predicoes//Nao Personalisado//" + u.getCodigo() + "_comparacaoPrecicaoNaoPersonalisado.csv");

        for (Hating h : u.getHatingNaoPersonalisado()) {

            for (Hating h2 : u.getHatings()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    compracao.Gravar(h.getcodItem() + " : " + h.getHating() + " : " + h2.getHating());
                }
            }

        }
        compracao.FechaEscrita();
    }

    public void ImprimeMetricasNaoPersonalisado(List<Usuario> usuarios) {

        EscritorDeArquivos metricas = new EscritorDeArquivos("Metricas//Nao Personalisado//metricas.csv");
        metricas.Gravar("Usuário;MAE;MSE;MAPE;RMSE;MAP;F1");

        for (Usuario u : usuarios) {

            metricas.Gravar(u.getCodigo() + ";" + u.getNaoPersonalisadoMAE() + ";" + u.getNaoPersonalisadoMSE() + ";" + u.getNaoPersonalisadoMAPE() + ";" + u.getNaoPersonalisadoRMSE()+";"+u.getNaoPersonalisadoMap()+";"+u.getNaoPersonalisadoF1());
        }

        metricas.FechaEscrita();

    }

    //########################## Conteúdo ##########################//
    public void ImprimeTFIDF(List<Item> itens, List<Palavra> termosOfensivos) {

        EscritorDeArquivos tfidf = new EscritorDeArquivos("Metricas//TFIDF//tfidf.csv");
        String linha = "";

        //Imprime o Cabeçalho
        linha += "Comentario;";
        for (Palavra termo : termosOfensivos) {

            linha += termo.getPalavra() + ";";
        }

        tfidf.Gravar(linha);

        for (Item item : itens) {

            linha = "";
            linha += item.getCodigo() + ";";
            for (Palavra termo : termosOfensivos) {
                linha += String.format("%.02f", item.getTFIDF(termo.getPalavra())) + ";";
            }
            tfidf.Gravar(linha);
        }

    }

    public void ImprimeRocchioMatriz(List<TfIdf> rocchio, String codigoUsuario) {

        EscritorDeArquivos rocchioEscritor = new EscritorDeArquivos("Predicoes//Conteudo//" + codigoUsuario + "_Rocchio.csv", true);

        for (TfIdf r : rocchio) {
            rocchioEscritor.Gravar(r.getPalavra() + ";" + r.getTfIdf());
        }
        rocchioEscritor.FechaEscrita();
    }

    public void ImprimeRocchioMatriz2(List<TfIdf> rocchio, String codigoUsuario) {

        EscritorDeArquivos rocchioEscritor = new EscritorDeArquivos("Predicoes//Conteudo//Rocchio//" + codigoUsuario + ".txt", true);

        String texto = "";

        if (!teste2) {

            EscritorDeArquivos rocchioHating2 = new EscritorDeArquivos("Predicoes//Conteudo//OrdemPalavra.csv");

            for (TfIdf r : rocchio) {
                texto += r.getPalavra() + " ";
            }
            rocchioHating2.Gravar(texto);
            rocchioHating2.FechaEscrita();

        }

        texto = "";
        teste2 = true;
        for (TfIdf r : rocchio) {
            texto += r.getTfIdf() + " ";
        }
        rocchioEscritor.Gravar(texto);
        rocchioEscritor.FechaEscrita();
    }

    public void ImpremeHatingConteudo(Usuario u) {

        EscritorDeArquivos rocchioHating = new EscritorDeArquivos("Predicoes//Conteudo//" + u.getCodigo() + "_HatingsCalculados.csv");
        rocchioHating.Gravar("Comentario;Hating");

        for (Hating h : u.getHatingBaseadoEmConteudo()) {
            rocchioHating.Gravar(h.getcodItem() + ";" + h.getHating());
        }

//        rocchioHating.FechaEscrita();
    }

    public void ImpremeHatingConteudo2(Usuario u) {

        EscritorDeArquivos rocchioHating = new EscritorDeArquivos("Predicoes//Conteudo//Rating//" + u.getCodigo() + ".txt");

        String texto = "";

        for (Hating h : u.getHatingBaseadoEmConteudo()) {
            texto += h.getcodItem() + ":" + h.getHating() + " ";
        }

        teste = true;

        rocchioHating.Gravar(texto);
        rocchioHating.FechaEscrita();

    }
    
     public void ImprimePrecisaoERevocaoConteudo(List<PrecisaoRevocacao> prereovc, String codigoItem) {
        EscritorDeArquivos precisaoRevocacao = new EscritorDeArquivos("Predicoes//Conteudo//" + codigoItem + "_PrecisaoRevocacao.csv");

        precisaoRevocacao.Gravar("Item;Revocacao;Precisao");

        for (PrecisaoRevocacao pr : prereovc) {
            precisaoRevocacao.Gravar(pr.getItem() + ";" + pr.getRevocacao() + ";" + pr.getPrecisao());
        }
        precisaoRevocacao.FechaEscrita();
    }
    
     
     public void ImprimeMetricasConteudo(List<Usuario> usuarios) {

        EscritorDeArquivos metricas = new EscritorDeArquivos("Metricas//Conteudo//metricas.csv");
        metricas.Gravar("Usuário;MAE;MSE;MAPE;RMSE;MAP;F1");

        for (Usuario u : usuarios) {

            metricas.Gravar(u.getCodigo() + ";" + u.getConteudoMAE() + ";" + u.getConteudoMSE() + ";" + u.getConteudoMAPE() + ";" + u.getConteudoRMSE()+";"+u.getConteudoMap()+";"+u.getConteudoF1());
        }

        metricas.FechaEscrita();

    }


    public void ImprimeMetodoExtraordinarioRamon2(List<TfIdf> tfIdf, double hating, String CodigoUsuario, String CodigoComentario) {

        EscritorDeArquivos imp = new EscritorDeArquivos("Teste//" + CodigoUsuario + "//Formato1//" + hating + "_" + CodigoComentario + ".txt");

        String texto = "";

        System.out.println("palavras");

        for (TfIdf tf : tfIdf) {
            texto += tf.getTfIdf() + " ";
            System.out.print(tf.getPalavra() + " ");
        }
        System.out.println();
        imp.Gravar(texto);
        imp.FechaEscrita();

        int Agressivo = 0;

        if (hating >= 4.0) {
            Agressivo = 1;

        } else {
            Agressivo = 0;
        }

        EscritorDeArquivos imp2 = new EscritorDeArquivos("Teste//" + CodigoUsuario + "//Formato2//" + Agressivo + "_" + CodigoComentario + ".txt");

        String texto2 = "";

        for (TfIdf tf : tfIdf) {
            texto2 += tf.getTfIdf() + " ";
        }

        imp2.Gravar(texto2);
        imp2.FechaEscrita();

    }

}
