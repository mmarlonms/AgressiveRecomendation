<?php
require_once 'controladora.php';


$c = new controladora();
$c->Ler("");