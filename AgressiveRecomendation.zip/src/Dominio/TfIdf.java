/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Marlon Miranda
 */
public class TfIdf {

    private String palavra;
    private double tfIdf;

    public TfIdf(String p, double t) {
        this.palavra = p;
        this.tfIdf = t;
    }

    public String getPalavra() {
        return this.palavra;
    }

    public double getTfIdf() {
        return this.tfIdf;
    }

}
