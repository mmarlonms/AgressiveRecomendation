<?php

require_once 'acessodados/AcessoComentarios.php';

class controladora {

    private $acesso;
    private $videos;
    private $posicaoVideo = 0;
    private $cont = 0;
    function __construct() {
        $this->acesso = new AcessoDados;
        $this->videos = array();


        $this->videos[] = "td4s51ghmXE"; //Marco Feliciano
        $this->videos[] = "KICHV9G4qmY"; //Biel
        $this->videos[] = "t11JYaJcpxg"; //Porta dos fundos Deus
        $this->videos[] = "p8jB27VAKa8"; //Gean Wilis
        $this->videos[] = "cHkCN6EL238"; //// Dilma e PT
    }

    public function Ler($pageToken) {







        $url = 'https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&start-index=100&maxResults=100&videoId=cHkCN6EL238&key=AIzaSyCx6r6JSpkneTRdXI8GL-RqMx9PJh7gdMY&pageToken=' . $pageToken;
        $JSON = file_get_contents($url);



        $json = json_decode($JSON);

        echo "<pre>";

       

        $nextPageToken = $json->nextPageToken;


        $comentarios = $json->items;
       
        //navega pelos elementos do array, imprimindo cada empregado
        foreach ($comentarios as $e) {
            echo "Numero: " . $this->cont. "<br/>";
            echo "Id: " . $e->snippet->topLevelComment->id . "<br/>";
            echo "Comentario: " . $e->snippet->topLevelComment->snippet->textDisplay . "<br/>";
            echo "VideoID: " . $e->snippet->topLevelComment->snippet->videoId . "<br/>";
            echo "Data: " . $e->snippet->topLevelComment->snippet->publishedAt . "<br/>";


            echo "<hr/>";
            $this->cont++;
        }


        if ($this->nextPageToken != 0) {
            $this->Ler($nextPageToken);
        } else {
            if ($this->posicaoVideo < 4) {
                $this->posicaoVideo++;
                $this->Ler("");
            }
        }
    }

}
