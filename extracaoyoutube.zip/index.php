<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <title>Extrator Youtube</title>

        <script>


            var cont = 0;
            var parar = 0;
            var arrayDados = [];
            var videos = [];
            var codVIdeo = 0;


//            videos.push("td4s51ghmXE"); //Marco Feliciano
            videos.push("KICHV9G4qmY"); //Biel
            videos.push("t11JYaJcpxg"); //Porta dos fundos Deus
            videos.push("p8jB27VAKa8"); //Gean Wilis
            videos.push("cHkCN6EL238"); //// Dilma e PT


            $(document).ready(function() {
                Proximos100("");
            });
            function Proximos100(pageToken) {

                var nextPageToken;

                $.ajax({
                    url: "https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&start-index=100&maxResults=100&videoId="+videos[codVIdeo]+"&key=AIzaSyCx6r6JSpkneTRdXI8GL-RqMx9PJh7gdMY&pageToken=" + pageToken,
                    dataType: 'json',
                    success: function(json) {


                        for (var i = 0; i < json.items.length; i++) {

                            var dados = {
                                comentario: json.items[i].snippet.topLevelComment.snippet.textDisplay,
                                video: json.items[i].snippet.videoId,
                                data: json.items[i].snippet.topLevelComment.snippet.publishedAt,
                                id: json.items[i].snippet.topLevelComment.id

                            };

                            $("#ul_coments").append(
                                "Numero:" +cont +"<br/>"+
                                "comentario:" +json.items[i].snippet.topLevelComment.snippet.textDisplay +"<br/>"+
                                "video: "+json.items[i].snippet.videoId+"<br/>"+
                                "data: "+json.items[i].snippet.topLevelComment.snippet.publishedAt+"<br/>"+
                                "id: "+json.items[i].snippet.topLevelComment.id+"<br/>"+
                                "<hr/>");
                            cont++;
                                
                            arrayDados.push(dados);

                        }

                        parar = parar + 10;
                        nextPageToken = json.nextPageToken;
                        if (nextPageToken !== 0)
                        {
                            $.ajax({
                                type: 'POST',
                                url: 'controladora.php',
                                dataType: 'json',
                                data: {'dados': JSON.stringify(arrayDados)},
                                success: function(msg) {
                                    alert(msg);
                                }
                            });

                            arrayDados = [];
                            Proximos100(nextPageToken);
                        } else {
                            if (codVIdeo < 4) {
                                codVIdeo++;
                                Proximos100("");
                            }
                        }

                    },
                    error: function(data) {
                        if (codVIdeo < 4) {
                            codVIdeo++;
                            Proximos100("");
                        }
                    }
                });
            }



        </script>


    </head>
    <body>
        <ul ID="ul_coments">

        </ul>

    </body>
</html>
