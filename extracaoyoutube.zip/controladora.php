<?php
require_once 'acessodados/AcessoComentarios.php';

if (isset($_POST['dados'])) {

    $ac = new AcessoDados();
   
    $json = $_POST['dados'];

    $dados = json_decode(($json));

    echo '<pre>';

    foreach ($dados as $id => $item) {

        
        $ac->CriarComentario($item->id, $item->video, $item->comentario, $item->data);
        
      
    }
    
} else {
    echo "Noooooooob";
}
  
  


