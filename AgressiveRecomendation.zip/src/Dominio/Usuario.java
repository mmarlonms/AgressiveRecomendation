/*
    Informações sobre os Usuários do Sistema
 */
package Dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 *
 */
public class Usuario extends ModeloDeRecomendacao implements Comparable<Usuario> {

    private List<TfIdf> RocchioMatriz;
    private List<Hating> HatingBaseadoEmConteudo;
    private List<Hating> HatingNaoPersonalisados;
    private List<Hating> hatingCalculadoAvaliacaoNaoPersonalisado;
    private List<PrecisaoRevocacao> precisaoRevocacaoNaoPersonalisado;
    private List<Hating> hatingCalculadoAvaliacaoConteudo;
    private List<PrecisaoRevocacao> precisaoRevocacaoConteudo;

    //Métricas
    private double naoPersonalisadoMae;
    private double naoPersonalisadoMse;
    private double naoPersonalisadoMape;
    private double naoPersonalisadoRmse;
    private double naoPersonalisadoF1;
    private double naoPersonalisadoMap;

    //Métricas
    private double conteudoMae;
    private double conteudoMse;
    private double conteudoMape;
    private double conteudoRmse;
    private double conteudoF1;
    private double conteudoMap;

    public Usuario() {
        super();
        this.RocchioMatriz = new ArrayList<>();
        this.HatingBaseadoEmConteudo = new ArrayList<>();
        this.HatingNaoPersonalisados = new ArrayList<>();
        this.hatingCalculadoAvaliacaoNaoPersonalisado = new ArrayList<>();
        this.precisaoRevocacaoNaoPersonalisado = new ArrayList<>();
        this.hatingCalculadoAvaliacaoConteudo = new ArrayList<>();
        this.precisaoRevocacaoConteudo = new ArrayList<>();

    }

    public Usuario(String cod, String nome) {

        super(cod, nome);
        this.RocchioMatriz = new ArrayList<>();
        this.HatingBaseadoEmConteudo = new ArrayList<>();
        this.HatingNaoPersonalisados = new ArrayList<>();
        this.hatingCalculadoAvaliacaoConteudo = new ArrayList<>();
        this.precisaoRevocacaoConteudo = new ArrayList<>();
        this.hatingCalculadoAvaliacaoNaoPersonalisado = new  ArrayList<>();
        this.precisaoRevocacaoNaoPersonalisado = new ArrayList<>();

    }

    public void addTfIdfRochio(TfIdf t) {

        this.RocchioMatriz.add(t);
    }

    public List<Hating> getHatingBaseadoEmConteudo() {
        return this.HatingBaseadoEmConteudo;
    }

    public void addHatingBaseadoEmConteudo(Hating h) {

        this.HatingBaseadoEmConteudo.add(h);
    }

    public List<Hating> getHatingNaoPersonalisado() {
        return this.HatingNaoPersonalisados;
    }

    public void addHatingNaoPersonalisado(Hating h) {

        this.HatingNaoPersonalisados.add(h);
    }
    
      public List<Hating> getHatingAvaliacaoConteudo() {
        return this.hatingCalculadoAvaliacaoConteudo;
    }

    public void addHatingAvaliacaoConteudo(Hating h) {

        this.hatingCalculadoAvaliacaoConteudo.add(h);
    }
    
      public List<PrecisaoRevocacao> getPrecisaoRevocacaoConteudo() {
        return this.precisaoRevocacaoConteudo;
    }

    public void addPrecisaoRevocacaoConteudo(PrecisaoRevocacao h) {

        this.precisaoRevocacaoConteudo.add(h);
    }

    public List<TfIdf> getRocchioMatriz() {
        Collections.sort(HatingBaseadoEmConteudo);
        return this.RocchioMatriz;
    }

    public void setHatingsAvaliacaoNaoPersonalisado(List<Hating> hatings) {
        this.hatingCalculadoAvaliacaoNaoPersonalisado = hatings;
    }

    public void addHatingsAvaliacaoNaoPersonalisado(Hating hatings) {
        this.hatingCalculadoAvaliacaoNaoPersonalisado.add(hatings);
    }

    public List<Hating> getHatingsAvaliacaoNaoPersonalisado() {
        return this.hatingCalculadoAvaliacaoNaoPersonalisado;
    }

    public List<PrecisaoRevocacao> getPrecisaoRevocacaoNaoPersonalisado() {
        return this.precisaoRevocacaoNaoPersonalisado;
    }

    public void addPrecisaoRevocacaoNaoPersonalisado(PrecisaoRevocacao h) {

        this.precisaoRevocacaoNaoPersonalisado.add(h);
    }

    public boolean classificouItem(String item) {
        for (Hating h : super.getHatings()) {
            if (h.getcodItem().equals(item)) {
                return true;
            }
        }

        return false;
    }

    public double getHatingItem(String item) {
        for (Hating h : super.getHatings()) {
            if (h.getcodItem().equals(item)) {
                return h.getHating();
            }
        }

        return 0;
    }

    public double getHocchioItem(String palavra) {
        for (TfIdf h : this.RocchioMatriz) {
            if (h.getPalavra().equals(palavra)) {
                return h.getTfIdf();
            }
        }

        return 0;
    }

    public void setNaoPersonalisadoMAE(double CalculoMAEusuario) {
        this.naoPersonalisadoMae = CalculoMAEusuario;
    }

    public double getNaoPersonalisadoMAE() {
        return this.naoPersonalisadoMae;
    }

    public void setNaoPersonalisadoMSE(double mse) {
        this.naoPersonalisadoMse = mse;
    }

    public double getNaoPersonalisadoMSE() {
        return this.naoPersonalisadoMse;
    }

    public void setNaoPersonalisadoMAPE(double mape) {
        this.naoPersonalisadoMape = mape;
    }

    public double getNaoPersonalisadoMAPE() {
        return this.naoPersonalisadoMape;
    }

    public void setNaoPersonalisadoRMSE(double mse) {
        this.naoPersonalisadoRmse = mse;
    }

    public double getNaoPersonalisadoRMSE() {
        return this.naoPersonalisadoRmse;
    }

    public void setNaoPersonalisadoMap(double map) {
        this.naoPersonalisadoMap = map;
    }

    public double getNaoPersonalisadoMap() {
        return this.naoPersonalisadoMap;
    }

    public void setNaoPersonalisadoF1(double f1) {
        this.naoPersonalisadoF1 = f1;
    }

    public double getNaoPersonalisadoF1() {
        return this.naoPersonalisadoF1;
    }

    public void setConteudoMAE(double CalculoMAEusuario) {
        this.conteudoMae = CalculoMAEusuario;
    }

    public double getConteudoMAE() {
        return this.conteudoMae;
    }

    public void setConteudoMSE(double mse) {
        this.conteudoMse = mse;
    }

    public double getConteudoMSE() {
        return this.conteudoMse;
    }

    public void setConteudoMAPE(double mape) {
        this.conteudoMape = mape;
    }

    public double getConteudoMAPE() {
        return this.conteudoMape;
    }

    public void setConteudoRMSE(double mse) {
        this.conteudoRmse = mse;
    }

    public double getConteudoRMSE() {
        return this.conteudoRmse;
    }

    public void setConteudoMap(double map) {
        this.conteudoMap = map;
    }

    public double getConteudoMap() {
        return this.conteudoMap;
    }

    public void setConteudoF1(double f1) {
        this.conteudoF1 = f1;
    }

    public double getConteudoF1() {
        return this.conteudoF1;
    }

    @Override
    public int compareTo(Usuario outroUsuario) {

        if (super.getSimilaridade() > outroUsuario.getSimilaridade()) {
            return -1;
        }
        if (this.getSimilaridade() < outroUsuario.getSimilaridade()) {
            return 1;
        }
        return 0;
    }

    public static Usuario getUsuario(List<Usuario> usuarios, String codUsuario) {

        for (Usuario u : usuarios) {
            if (u.getCodigo().equals(codUsuario)) {
                return u;
            }
        }
        return null;
    }

}
