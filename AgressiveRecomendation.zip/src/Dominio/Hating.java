/*
    Hating
 */
package Dominio;

/**
 *
 * @author Marlon Miranda
 *
 */
public class Hating implements Comparable<Hating> {

    private String codigoUsuario;
    private String codigoComentario;
    private double hating;

    public Hating() {
        this.codigoUsuario = "";
        this.codigoComentario = "";
        this.hating = 0;
    }

    public Hating(String codUsuario, String codComentario, double n) {
        this.codigoUsuario = codUsuario;
        this.codigoComentario = codComentario;
        this.hating = n;
    }

    public String getCodUsuario() {
        return this.codigoUsuario;
    }

    public double getHating() {
        return this.hating;
    }

    public String getcodItem() {
        return this.codigoComentario;
    }

    @Override
    public int compareTo(Hating t) {

        if (this.getHating() > t.getHating()) {
            return -1;
        }
        if (this.getHating() < t.getHating()) {
            return 1;
        }
        return 0;
    }

}
