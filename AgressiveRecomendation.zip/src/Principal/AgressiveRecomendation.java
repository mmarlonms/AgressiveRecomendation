/*
    Este sistema consiste em um sistema de Recomendação para avaliação de comentários
    agressivos no You Tube.
 */
package Principal;

import Dominio.Controladora;
import Dominio.Usuario;

/**
 *
 * @author Marlon Miranda
 *
 */
public class AgressiveRecomendation {

    public static void main(String[] args) {

        Controladora c = new Controladora();

//        c.RankingHatingIntensPorUsuarioFULL(100,1);
        c.RankingHatingIntensPorIntensFULL(30, 2);
//        c.RankingHatingNaoPersonalizadoFULL(3);
//        c.RankingConteudoFULL(3);

//        c.MetodoExtraordinarioDoRamon();
//       c.MetodoExtraordinarioDoRamon2();
        System.out.println("FIM");

    }

}
