/*
    Modelo base
 */
package Dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 */
public class ModeloDeRecomendacao {

    //Atributos
    private String codigo;
    private String texto;
    private double similidade;

    //Métricas
    private double mae;
    private double mse;
    private double mape;
    private double rmse;
    private double map;
    private double f1;

    //Listas
    private List<Hating> hatings;
    private List<Hating> hatingCalculado;
    private List<Hating> itensRelevantes;
    private List<PrecisaoRevocacao> precisaoRevocacao;
    private List<Hating> hatingCalculadoAvaliacao;
    private List<Hating> TestePrecisaoRevocacao;
    private List<Hating> TreinoPrecisaoRevocacao;

    public ModeloDeRecomendacao() {

        this.codigo = "";
        this.texto = "";

        this.mae = 0;
        this.mse = 0;
        this.mape = 0;
        this.rmse = 0;

        this.hatings = new ArrayList<>();
        this.hatingCalculado = new ArrayList<>();
        this.itensRelevantes = new ArrayList<>();
        this.precisaoRevocacao = new ArrayList<>();
        this.hatingCalculadoAvaliacao = new ArrayList<>();
         this.TestePrecisaoRevocacao = new ArrayList<>();
    }

    public ModeloDeRecomendacao(String cod, String text) {

        this.codigo = cod;
        this.texto = text;

        this.mae = 0;
        this.mse = 0;
        this.mape = 0;
        this.rmse = 0;

        this.hatings = new ArrayList<>();
        this.hatingCalculadoAvaliacao = new ArrayList<>();
        this.hatingCalculado = new ArrayList<>();
        this.itensRelevantes = new ArrayList<>();
        this.precisaoRevocacao = new ArrayList<>();
         this.TestePrecisaoRevocacao = new ArrayList<>();
    }

    public String getCodigo() {
        return this.codigo;
    }

    public String getTexto() {
        return this.texto;
    }

    public List<Hating> getHatingCalculado() {
        Collections.sort(hatingCalculado);
        return this.hatingCalculado;
    }

    public void zeraArray() {
        this.hatingCalculadoAvaliacao = new ArrayList<>();
        this.hatingCalculado = new ArrayList<>();
    }

    public void addHatingCalculado(Hating h) {
        this.hatingCalculado.add(h);
    }

    public void setHatings(List<Hating> hatings) {
        this.hatings = hatings;
    }

    public List<Hating> getHatings() {
        return this.hatings;
    }

    public void setHatingsAvaliacao(List<Hating> hatings) {
        this.hatingCalculadoAvaliacao = hatings;
    }

    public void addHatingsAvaliacao(Hating hatings) {
        this.hatingCalculadoAvaliacao.add(hatings);
    }

    public List<Hating> getHatingsAvaliacao() {
        Collections.sort(hatingCalculadoAvaliacao);
        return this.hatingCalculadoAvaliacao;

    }
    public List<Hating> getTestePrecisaoRevocacao() {
        return this.TestePrecisaoRevocacao;
    }

    public void addTestePrecisaoRevocacao(Hating h) {

        this.TestePrecisaoRevocacao.add(h);
    }

    public void setTestePrecisaoRevocacao(List<Hating> h) {

        this.TestePrecisaoRevocacao = h;
    }

    public List<Hating> getTreinoPrecisaoRevocacao() {
        return this.TreinoPrecisaoRevocacao;
    }

    public void addTesteTreinoPrecisaoRevocacao(Hating h) {

        this.TreinoPrecisaoRevocacao.add(h);
    }

    public void setTreinoPrecisaoRevocacao(List<Hating> h) {

        this.TreinoPrecisaoRevocacao = h;
    }

    public void setSimilidade(double s) {
        this.similidade = s;
    }

    public double getSimilaridade() {
        return this.similidade;
    }

    public void setMAE(double CalculoMAEusuario) {
        this.mae = CalculoMAEusuario;
    }

    public double getMAE() {
        return this.mae;
    }

    public void setMSE(double mse) {
        this.mse = mse;
    }

    public double getMSE() {
        return this.mse;
    }

    public void setMAPE(double mape) {
        this.mape = mape;
    }

    public double getMAPE() {
        return this.mape;
    }

    public void setRMSE(double mse) {
        this.rmse = mse;
    }

    public double getRMSE() {
        return this.rmse;
    }

    public void setItensRelevantes(List<Hating> itensRelevantes) {
        this.itensRelevantes = itensRelevantes;
    }

    public List<Hating> getItensRelevantes() {
        return this.itensRelevantes;
    }

    public List<PrecisaoRevocacao> getPrecisaoReovocacao() {
        return this.precisaoRevocacao;
    }

    public void setPrecisaoReovcacao(List<PrecisaoRevocacao> p) {
        this.precisaoRevocacao = p;
    }

    public void addPrecisaoRevocacao(PrecisaoRevocacao p) {
        this.precisaoRevocacao.add(p);
    }

    public void setMap(double map) {
        this.map = map;
    }

    public double getMap() {
        return this.map;
    }

    public void setF1(double f1) {
        this.f1 = f1;
    }

    public double getF1() {
        return this.f1;
    }

}
