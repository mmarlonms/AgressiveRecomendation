/*
    Informações sobre os Itens
 */
package Dominio;

import Util.TransformacoesEmTexto;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 *
 */
public class Item extends ModeloDeRecomendacao implements Comparable<Item> {

    private List<String> termos;
    List<String> visaoLogica;
    private boolean calculoVisao;
    private String palavraComMaiorFrequencia;
    private List<TfIdf> tfIdf;

    public Item(String codigo, String texto) {
        super(codigo, texto);
        this.tfIdf = new ArrayList<>();
        this.termos = new ArrayList<>();
        this.visaoLogica = new ArrayList<>();
        this.palavraComMaiorFrequencia = "";
        
        TransformacoesEmTexto.CriaRepresentacao(this);
        this.calculaVisaoLogica();
    }

    public Item() {
        super();
        this.tfIdf = new ArrayList<>();
        this.termos = new ArrayList<>();
        this.visaoLogica = new ArrayList<>();
        this.palavraComMaiorFrequencia = "";
    }
    
    public double getTFIDF(String palavra){
        for(TfIdf t : this.tfIdf){
            if(t.getPalavra().equals(palavra))
                return t.getTfIdf();
        }
        
        return 0;
    }
    

    public int definePlavraComMaiorFrequencia() {

        int frequencia = 0;
        int temp = 0;

        for (String s : termos) {

            for (String t : termos) {
                if (s.equals(t)) {
                    temp++;
                }
            }
            if (temp > frequencia) {
                frequencia = temp;
                this.palavraComMaiorFrequencia = s + " f: " + frequencia + " " + super.getCodigo();
            }

            temp = 0;
        }

        return frequencia;
    }

    public int getFrequenciaNoDocumento(String termo) {
        int cont = 0;
        for (String t : termos) {
            if (t.equals(termo)) {
                cont++;
            }
        }
        return cont;
    }
    
    public void calculaVisaoLogica() {

        for (String termo : termos) {

            if (!visaoLogica.contains(termo)) {
                visaoLogica.add(termo);
            }
        }
     
    }


    public boolean foiClassificadoPor(String codUsuario) {
        for (Hating h : super.getHatings()) {
            if (h.getCodUsuario().equals(codUsuario)) {
                return true;
            }
        }

        return false;
    }

    public static Item getItem(List<Item> itens, String codItem) {

        for (Item i : itens) {
            if (i.getCodigo().equals(codItem)) {
                return i;
            }
        }
        return null;
    }

    public int getQntTermos() {
        return this.termos.size();
    }

    public List<String> getTermos() {
        return this.visaoLogica;
    }

    public List<String> getTermosOrdenados() {
        Collections.sort(this.visaoLogica);
        return this.visaoLogica;
    }

    public void addTermo(String termo) {
        this.termos.add(termo);
        this.calculoVisao = false;
    }

    

    public List<TfIdf> getTfIdf() {
        return this.tfIdf;
    }

    public void addTfIdf(TfIdf t) {
        this.tfIdf.add(t);
    }

    public boolean existePalavra(String palavra) {
        return termos.contains(palavra);
    }

    public List pegaVisaoLogica() {
        if (!calculoVisao) {
            calculaVisaoLogica();
        }

        return this.visaoLogica;
    }

    public List pegaTermosDocumento() {
        return this.termos;
    }

    public int getNumTotalDeTermos() {
        return this.termos.size();
    }

    public void imprime() {
        calculaVisaoLogica();

        System.out.println("Termos : \n");
        for (String termo : termos) {

            System.out.println("|" + termo + "|");
        }
        System.out.println("Visão logica : \n");
        for (String termo : visaoLogica) {
            System.out.println("|" + termo + "|");
        }

    }

    @Override
    public int compareTo(Item outroItem) {

        if (super.getSimilaridade() > outroItem.getSimilaridade()) {
            return -1;
        }
        if (this.getSimilaridade() < outroItem.getSimilaridade()) {
            return 1;
        }
        return 0;
    }
}
