/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Marlon Miranda
 */
public class Palavra {

    private String palavra;
    private float idf;

    public Palavra(String p) {
        this.palavra = p;
    }

    public String getPalavra() {
        return this.palavra;
    }

    public float getIdf() {
        return idf;
    }

    public void setIdf(float idf) {
        this.idf = idf;
    }

}
