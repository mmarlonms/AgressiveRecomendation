/*
    Realiza o controle das classes
 */
package Dominio;

import Calculadora.Calculos;
import Util.EscritorDeArquivos;
import Util.Impressora;
import Util.LeitorDeArquivos;
import java.io.File;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 *
 */
public final class Controladora {

    //Serviços
    Calculos calculos;
    LeitorDeArquivos leitor;
    EscritorDeArquivos escritor;
    Impressora impressora;

    //Variávies
    private List<Usuario> usuarios;
    private List<Item> itens;
    private List<Palavra> vocabulario;

    public Controladora() {

        this.leitor = new LeitorDeArquivos();
        this.calculos = new Calculos();
        this.impressora = new Impressora();

        this.usuarios = new ArrayList<>();
        this.itens = new ArrayList<>();
        this.vocabulario = new ArrayList<>();

        LerArquivos();
    }

    public void LerArquivos() {
        /*
        Realiza a leitrua dos arquivos:
        user.csv -> Informações sobre os usuários
        itens.csv -> Informações sobre os itens avaliados
        hatings.csv -> Informações sobre as avaliações dos usuários sobre os itens  
        palavras.csv -> Palavras ofencivas nos termos
         */

        System.out.println("Lendo documentos...");

        this.usuarios = leitor.lerUsuarios();
        this.itens = leitor.lerItens();
//        this.vocabulario = this.calculos.CriarVocabulario(itens);
        this.vocabulario = leitor.lerTermosOfenciovos();

        for (Usuario u : this.usuarios) {
            u.setHatings(leitor.lerHatingsUser(u.getCodigo()));
        }

        for (Item i : this.itens) {
            i.setHatings(leitor.lerHatingsItem(i.getCodigo()));
        }

        System.out.println("Fim leitura documentos");
    }

    /*
        ####################  Métodos do TCC ################################
     */
    public void RankingHatingIntensPorUsuarioFULL(int proximidade, int diferencialMinimoRelevante) {

        System.out.println("Iniciando Análises do Usuário...");

        int cont = 0;
        for (Usuario u : usuarios) {

            System.out.println("Lendo usuário " + cont++);
            RankingHatingIntensPorUsuario(u, proximidade, diferencialMinimoRelevante);

        }

        impressora.ImprimeMetricasUsuario(usuarios);
        System.out.println("Análises dos usuários finalisadas...");
    }

    public void RankingHatingIntensPorIntensFULL(int proximidade, int diferencialMinimoRelevante) {

        System.out.println("Iniciando Análises dos Itens...");

        int cont = 0;
        for (Item i : itens) {
            System.out.println("Lendo Item " + cont++);
            RankingHatingIntensPorIntens(i, proximidade, diferencialMinimoRelevante);
        }

        this.impressora.ImprimeMetricasItem(itens);

        System.out.println("Análises dos Itens finalisadas...");
    }

    public void RankingHatingNaoPersonalizadoFULL(int diferencialMinimoRelevante) {

        System.out.println("Iniciando Análises Não Personalisadas...");
        int cont = 0;
        for (Usuario u : usuarios) {
            System.out.println("Lendo usuário " + cont++);
            for (Item i : itens) {
                double hating = this.calculos.RankingHatingNaoPersonalizado(i);
                u.addHatingNaoPersonalisado(new Hating(u.getCodigo(), i.getCodigo(), hating));
            }
            u.setNaoPersonalisadoMAE(this.calculos.CalculoMAEusuario(u.getHatings(), u.getHatingNaoPersonalisado()));
            u.setNaoPersonalisadoMSE(this.calculos.CalculoMSEusuario(u.getHatings(), u.getHatingNaoPersonalisado()));
            u.setNaoPersonalisadoMAPE(this.calculos.CalculoMAPEusuario(u.getHatings(), u.getHatingNaoPersonalisado()));
            u.setNaoPersonalisadoRMSE(this.calculos.CalculoRMSEusuario(u.getHatings(), u.getHatingNaoPersonalisado()));

            //Realiza os calculos de Precisão e Revocação do Usuário
            this.calculos.calculaPrecisaoRevocacaoUsuarioNaoPersonalisado(u, diferencialMinimoRelevante);

            //imprime as precisões re revocações dos usuários
            this.impressora.ImprimePrecisaoERevocaoNaoPersonalisado(u.getPrecisaoRevocacaoNaoPersonalisado(), u.getCodigo());
        }
//        impressora.ImprimeRankingHatingNaoPersonalizadoFULL(usuarios.get(0).getHatingNaoPersonalisado());
        impressora.ImprimeMetricasNaoPersonalisado(usuarios);

        System.out.println("Análises Não Personalisadas finalisadas...");
    }

    public void RankingConteudoFULL(int diferencialMinimoRelevante) {

        System.out.println("Iniciando Análises Baseada Em Conteúdo...");

        this.calculos.CalculaTFIDF(this.vocabulario, this.itens);
        
        System.out.println("Número total de Itens "+this.vocabulario.size());
        System.out.println("Número total de Itens "+this.itens.size());
        
        
//        this.impressora.ImprimeTFIDF(this.itens, this.vocabulario);
        int cont = 0;
        
      
        
        
        for (Usuario u : this.usuarios) {
              
            cont++;
            System.out.println("Lendo usuário " + cont);
            //Calcula Matriz Rocchio
            System.out.println("Calculando Rocchio... " + cont);

            this.calculos.CalculaRocchioMatriz(u, this.itens, this.vocabulario);
            //Imprime Matriz Rocchio

           // System.out.println("Imprmindo Rocchio...");

            //this.impressora.ImprimeRocchioMatriz(u.getRocchioMatriz(), u.getCodigo());
            //Calcula Hating Baseado no Conteúdo
           System.out.println("Definindo Hating... " + cont);
            this.calculos.DefineHatingConteudo(u, itens);
            //Imprime Hating Baseado no Conteúdo
            //this.impressora.ImpremeHatingConteudo(u);

            u.setConteudoMAE(this.calculos.CalculoMAEusuario(u.getHatings(), u.getHatingBaseadoEmConteudo()));
            u.setConteudoMSE(this.calculos.CalculoMSEusuario(u.getHatings(), u.getHatingBaseadoEmConteudo()));
            u.setConteudoMAPE(this.calculos.CalculoMAPEusuario(u.getHatings(), u.getHatingBaseadoEmConteudo()));
            u.setConteudoRMSE(this.calculos.CalculoRMSEusuario(u.getHatings(), u.getHatingBaseadoEmConteudo()));

              System.out.println("Calculando PrecisaoeRevocacação... " + cont);
            //Realiza os calculos de Precisão e Revocação do Usuário
            this.calculos.calculaPrecisaoRevocacaoUsuarioConteudo(u, diferencialMinimoRelevante);

            //imprime as precisões re revocações dos usuários
            this.impressora.ImprimePrecisaoERevocaoConteudo(u.getPrecisaoRevocacaoConteudo(), u.getCodigo());
            
         

        }

        impressora.ImprimeMetricasConteudo(usuarios);

        System.out.println("Análises Baseada Em Conteúdo finalisadas...");
    }

    /*
        ####################  Métodos Auxiliares ################################
     */
    public void RankingHatingIntensPorUsuario(Usuario usuario, int proximidade, int diferencialMinimoRelevante) {

        //Separa as Bases em teste e treino
        usuario.setTreinoPrecisaoRevocacao(usuario.getHatings().subList(0, usuario.getHatings().size() / 2));
        usuario.setTestePrecisaoRevocacao(usuario.getHatings().subList(usuario.getHatings().size() / 2, usuario.getHatings().size()));

        List<Usuario> knn;

        //utiliza a base de treino como base para medir a predição
        for (Item i : itens) {

            boolean avaliou = false;

            //Verifica se o item está dentro os itens de teste, caso esteja não é calcula o hatings pra estes itens
            for (Hating h : usuario.getTreinoPrecisaoRevocacao()) {
                if (h.getcodItem().equals(i.getCodigo())) {
                    avaliou = true;
                }
            }

            if (!avaliou) {
                knn = calculos.CalculaKNNUsuario(usuario, usuarios, proximidade, i.getCodigo());
                usuario.addHatingCalculado(new Hating(usuario.getCodigo(), i.getCodigo(), calculos.DefineHatingUsuario(knn, i)));
                //this.impressora.ImpreimeSimilaridadeUsuario(knn, usuario.getCodigo(), i.getCodigo());
            }

        }

        //Define as Métricas do Usuário
        usuario.setMAE(this.calculos.CalculoMAEusuario(usuario.getTestePrecisaoRevocacao(), usuario.getHatingCalculado()));
        usuario.setMSE(this.calculos.CalculoMSEusuario(usuario.getTestePrecisaoRevocacao(), usuario.getHatingCalculado()));
        usuario.setMAPE(this.calculos.CalculoMAPEusuario(usuario.getTestePrecisaoRevocacao(), usuario.getHatingCalculado()));
        usuario.setRMSE(this.calculos.CalculoRMSEusuario(usuario.getTestePrecisaoRevocacao(), usuario.getHatingCalculado()));

        //Realiza os calculos de Precisão e Revocação do Usuário
        this.calculos.calculaPrecisaoRevocacaoUsuario(usuario, diferencialMinimoRelevante);

        //imprime as precisões re revocações dos usuários
        this.impressora.ImprimePrecisaoERevocaoUsuario(usuario.getPrecisaoReovocacao(), usuario.getCodigo());
    }

    public void RankingHatingIntensPorIntens(Item item, int proximidade, int diferencialMinimoRelevante) {
        /*
            Verifica se o item já foi avaliado por determinado Usuario dentro da lista de todos os usuarios.
            Caso não tenha avaliado é gerado o KNN dos visinhos mais próximos que avaliaram o item em questão.
            Realiza o calculo da pre-avaliação do item com base na avaliação dos visinhos mais próximos.
         */
        item.setTreinoPrecisaoRevocacao(item.getHatings().subList(0, item.getHatings().size() / 2));
        item.setTestePrecisaoRevocacao(item.getHatings().subList(item.getHatings().size() / 2, item.getHatings().size()));

        List<Item> knn;

        for (Usuario u : usuarios) {

            boolean avaliou = false;

            //Verifica se o item está dentro os itens de teste, caso esteja não é calcula o hatings pra estes itens
            for (Hating h : item.getTreinoPrecisaoRevocacao()) {
                if (h.getCodUsuario().equals(u.getCodigo())) {
                    avaliou = true;
                }
            }

            if (!avaliou) {

                knn = calculos.CalculaKNNItens(item, this.itens, proximidade, u.getCodigo());

                //this.impressora.ImpreimeSimilaridadeItem(knn, item.getCodigo(), u.getCodigo());
                item.addHatingCalculado(new Hating(u.getCodigo(), item.getCodigo(), calculos.DefineHatingItem(knn, u)));
            }
        }

        //Define as Métricas do Item
        item.setMAE(this.calculos.CalculoMAEItem(item.getTestePrecisaoRevocacao(), item.getHatingCalculado()));
        item.setMSE(this.calculos.CalculoMSEItem(item.getTestePrecisaoRevocacao(), item.getHatingCalculado()));
        item.setMAPE(this.calculos.CalculoMAPEItem(item.getTestePrecisaoRevocacao(), item.getHatingCalculado()));
        item.setRMSE(this.calculos.CalculoRMSEItem(item.getTestePrecisaoRevocacao(), item.getHatingCalculado()));

        //Realiza os calculos de Precisão e Revocação do Item
        this.calculos.calculaPrecisaoRevocacaoItens(item, diferencialMinimoRelevante);

        //imprime as precisões re revocações dos usuários
        this.impressora.ImprimePrecisaoERevocaoItem(item.getPrecisaoReovocacao(), item.getCodigo());
    }

    public void MetodoExtraordinarioDoRamon() {

        System.out.println("Iniciando MetodoExtraordinarioDoRamon...");

        this.calculos.CalculaTFIDF(this.vocabulario, this.itens);

//        this.impressora.ImprimeTFIDF(this.itens, this.vocabulario);
        int cont = 0;

        for (Usuario u : this.usuarios) {

            //Calcula Matriz Rocchio
            System.out.println("Calculando Rocchio... " + cont++);

            this.calculos.CalculaRocchioMatriz(u, this.itens, this.vocabulario);
            //Imprime Matriz Rocchio

            System.out.println("Imprmindo Rocchio...");

            this.impressora.ImprimeRocchioMatriz2(u.getRocchioMatriz(), u.getCodigo());

            //Calcula Hating Baseado no Conteúdo
            this.calculos.DefineHatingConteudo(u, itens);
            //Imprime Hating Baseado no Conteúdo
            this.impressora.ImpremeHatingConteudo2(u);
        }

        System.out.println("FIM MetodoExtraordinarioDoRamon...");

    }

    public void MetodoExtraordinarioDoRamon2() {

        System.out.println("Iniciando MetodoExtraordinarioDoRamon...");

        criaDiretorio(usuarios);
        this.calculos.CalculaTFIDF(this.vocabulario, this.itens);

//        this.impressora.ImprimeTFIDF(this.itens, this.vocabulario);
        int cont = 0;

        for (Usuario u : this.usuarios) {

            //Calcula Matriz Rocchio
            for (Hating h : u.getHatings()) {
                Item i = Item.getItem(itens, h.getcodItem());
                this.impressora.ImprimeMetodoExtraordinarioRamon2(i.getTfIdf(), h.getHating(), u.getCodigo(), i.getCodigo());
            }

            //Calcula Hating Baseado no Conteúdo
            this.calculos.DefineHatingConteudo(u, itens);
            //Imprime Hating Baseado no Conteúdo
            this.impressora.ImpremeHatingConteudo2(u);
        }

        System.out.println("FIM MetodoExtraordinarioDoRamon...");

    }

    public void criaDiretorio(List<Usuario> users) {

        for (Usuario u : users) {
            new File("E://DadosReais//Resultado//Teste//" + u.getCodigo()).mkdir();
            new File("E://DadosReais//Resultado//Teste//" + u.getCodigo() + "//Formato1").mkdir();
            new File("E://DadosReais//Resultado//Teste//" + u.getCodigo() + "//Formato2").mkdir();
        }
    }

}
