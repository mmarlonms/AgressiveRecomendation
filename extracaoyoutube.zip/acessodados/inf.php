<?php

//Homologação

$bdhost = "localhost";
$bduser = "root";
$bdpassword = "";
$bdbanco = "basededados";

