/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Marlon Miranda
 */
public class PrecisaoRevocacao {

    private double precisao;
    private double revocacao;
    private String item;

    public PrecisaoRevocacao(double p, double r) {

        this.revocacao = r;
        this.precisao = p;
    }
    
     public PrecisaoRevocacao(double p, double r, String item) {

        this.revocacao = r;
        this.precisao = p;
        this.item = item;
    }

    public double getPrecisao() {
        return this.precisao;
    }

    public double getRevocacao() {
        return this.revocacao;
    }
    
    public String getItem(){
        return this.item;
    }

}
