/*
    Realiza a Leitura dos Arquivos de texto
 */
package Util;

import Dominio.Item;
import Dominio.Hating;
import Dominio.Palavra;
import Dominio.Usuario;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 *
 */
public class LeitorDeArquivos {

    private String CaminhoBase = "E://DadosReais//Dados//";
    private String caminhoPalavrasOfencivas = "E://DadosReais//Dados//palavras.csv";
    private String ArquivoUsuarios = "user.csv";
    private String ArquivoComentarios = "itens.csv";
    private String ArquivoHatings = "hatings.csv";

    public List<Usuario> lerUsuarios() {

        List<Usuario> usuarios = new ArrayList<>();

        try {
            FileReader arq = new FileReader(CaminhoBase + ArquivoUsuarios);
            BufferedReader lerArq = new BufferedReader(arq);

            String linha = lerArq.readLine(); // lê a primeira linha
            // a variável "linha" recebe o valor "null" quando o processo
            // de repetição atingir o final do arquivo texto
            while (linha != null) {
                String[] aux = linha.split(";");
                usuarios.add(new Usuario(aux[0], aux[1]));
                linha = lerArq.readLine(); // lê da segunda até a última linha
            }
            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }

        return usuarios;
    }

    public List<Item> lerItens() {

        List<Item> comentarios = new ArrayList<>();

        try {
            FileReader arq = new FileReader(CaminhoBase + ArquivoComentarios);
            BufferedReader lerArq = new BufferedReader(arq);

            String linha = lerArq.readLine(); // lê a primeira linha
            // a variável "linha" recebe o valor "null" quando o processo
            // de repetição atingir o final do arquivo texto
            while (linha != null) {
                String[] aux = linha.split(";");
                comentarios.add(new Item(aux[0], aux[1]));
                linha = lerArq.readLine(); // lê da segunda até a última linha
            }

            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }

        return comentarios;
    }

    public List<Hating> lerHatingsUser(String codUsuario) {

        List<Hating> hatings = new ArrayList<>();

        try {
            FileReader arq = new FileReader(CaminhoBase + ArquivoHatings);
            BufferedReader lerArq = new BufferedReader(arq);

            String linha = lerArq.readLine(); // lê a primeira linha
            // a variável "linha" recebe o valor "null" quando o processo
            // de repetição atingir o final do arquivo texto
            while (linha != null) {

                String[] aux = linha.split(";");
                //Verifica se o hating é do usuário determinado.
                if (aux[0].toString().equals(codUsuario)) {
                    hatings.add(new Hating(aux[0], aux[1], Double.parseDouble(aux[2])));
                }
                linha = lerArq.readLine(); // lê da segunda até a última linha
            }

            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }

        return hatings;
    }

    public List<Hating> lerHatingsItem(String codItem) {

        List<Hating> hatings = new ArrayList<>();

        try {
            FileReader arq = new FileReader(CaminhoBase + ArquivoHatings);
            BufferedReader lerArq = new BufferedReader(arq);

            String linha = lerArq.readLine(); // lê a primeira linha
            // a variável "linha" recebe o valor "null" quando o processo
            // de repetição atingir o final do arquivo texto
            while (linha != null) {

                String[] aux = linha.split(";");
                //Verifica se o hating é do usuário determinado.
                if (aux[1].toString().equals(codItem)) {
                    hatings.add(new Hating(aux[0], aux[1], Double.parseDouble(aux[2])));
                }
                linha = lerArq.readLine(); // lê da segunda até a última linha
            }

            arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
        }

        return hatings;
    }

    //Realiza a leitura do .txt com as palavras ofencivas
    public List<Palavra> lerTermosOfenciovos() {

        String arquivoCSV = this.caminhoPalavrasOfencivas;
        BufferedReader br = null;
        String linha = "";
        List<Palavra> termosOfencivos = new ArrayList<>();

        try {
            br = new BufferedReader(new FileReader(arquivoCSV));
            while ((linha = br.readLine()) != null) {
                termosOfencivos.add(new Palavra(TransformacoesEmTexto.formatString(linha)));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return termosOfencivos;
    }
}
