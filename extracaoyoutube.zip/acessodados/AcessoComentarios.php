<?php

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);
/**
 *
 * @author Marlon
 * 
 *  Acesso aos dados de Deputados
 *  
 */
require_once 'DataBase.class.php';


class AcessoDados {

    private $db;


    function __construct() {
        $this->db = DataBase::getInstance();
    }

    public function CriarComentario($IDCOMENTARIO, $IDVIDEO, $COMENTARIO, $DATA) {


        $sql = "INSERT INTO `comentarios` (`IDCOMENTARIO`, `COMENTARIO`, `IDVIDEO`, `DATACOMENTARIO`) VALUES (:id_comentario, :comentario , :videoId, :data);";
                
        
        $parametros = array(
            ':id_comentario' => $IDCOMENTARIO,
            ':videoId' => $IDVIDEO,
            ':comentario' => $COMENTARIO,
            ':data' => $DATA,
        );

        $insere = $this->db->prepare($sql);

        try {

            $insere->execute($parametros);
        } catch (Exception $ex) {

            if ($ex->getCode() != 23000) {

                return $ex->getMessage();
            }
        }

        return "";
    }

   

}
