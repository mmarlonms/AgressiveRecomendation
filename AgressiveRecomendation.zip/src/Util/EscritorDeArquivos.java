/*
    Escre os Arquivos de Saida
 */
package Util;

import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author Marlon Miranda
 *
 *
 */
public class EscritorDeArquivos {

    private String CaminhoSaida = "E://DadosReais//Resultado//";
    FileWriter x;

    public EscritorDeArquivos(String arquivo, boolean sobrescreve) {

        this.CaminhoSaida += arquivo;

        try {
            x = new FileWriter(CaminhoSaida, sobrescreve);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Atenção", JOptionPane.WARNING_MESSAGE);
        }

    }

    public EscritorDeArquivos(String arquivo) {

        this.CaminhoSaida += arquivo;

        try {
            x = new FileWriter(CaminhoSaida, false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Atenção", JOptionPane.WARNING_MESSAGE);
        }

    }

    public void Gravar(String texto) {
        String conteudo = texto;
        try {
            conteudo += "\n"; // criando nova linha e recuo no arquivo              
            x.write(conteudo); // armazena o texto no objeto x, que aponta para o arquivo             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Atenção", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void FechaEscrita() {
        try {
            x.close(); // cria o arquivo
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Arquivo gravado com sucesso", "Concluído", JOptionPane.INFORMATION_MESSAGE);
        }
    }

}
