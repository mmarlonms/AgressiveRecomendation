<?php

Class Video {

    private $id_video;
    private $titulo_video;
    private $id_youtube;
    private $descricao_video;

    public function DefineDadosCriacao($id_video, $titulo_video, $id_youtube, $descricao_video) {

        $this->id_video = $id_video;
        $this->titulo_video = $titulo_video;
        $this->id_youtube = $id_youtube;
        $this->descricao_video = $descricao_video;
    }

}

Class Comentario {

    private $id_comentario;
    private $videoId;
    private $authorDisplayName;
    private $authorChannelUrl;
    private $authorChannelId;
    private $textDisplay;
    private $publishedAt;
    private $updatedAt;

    public function DefineDadosCriacao($id_comentario, $videoId, $authorDisplayName, $authorChannelUrl, $authorChannelId, $textDisplay, $publishedAt, $updatedAt) {

        $this->id_comentario = $id_comentario;
        $this->videoId = $videoId;
        $this->authorDisplayName = $authorDisplayName;
        $this->authorChannelUrl = $authorChannelUrl;
        $this->authorChannelId = $authorChannelId;
        $this->textDisplay = $authorChannelId;
        $this->publishedAt = $publishedAt;
        $this->updatedAt = $updatedAt;
    }

    public function Getid_comentario() {
        return $this->id_comentario;
    }

    public function GetvideoId() {
        return $this->videoId;
    }

    public function GetauthorDisplayName() {
        return $this->authorDisplayName;
    }

    public function GetauthorChannelUrl() {
        return $this->authorChannelUrl;
    }

    public function GetauthorChannelId() {
        return $this->authorChannelId;
    }

    public function GettextDisplay() {
        return $this->textDisplay;
    }

    public function GetpublishedAt() {
        return $this->publishedAt;
    }

    public function GetupdatedAt() {
        return $this->updatedAt;
    }


    
 

}
