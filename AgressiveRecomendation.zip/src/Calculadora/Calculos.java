/*
    Realiza os Calculos do Sistema
 */
package Calculadora;

import Dominio.Item;
import Dominio.Hating;
import Dominio.ModeloDeRecomendacao;
import Dominio.Palavra;
import Dominio.PrecisaoRevocacao;
import Dominio.TfIdf;
import Dominio.Usuario;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Marlon Miranda
 *
 */
public class Calculos {

    public double SimilariadedeUsuario(Usuario a, Usuario b) {
        /*
        Realiza o Calculo da Similariadade com base na distância do Cosseno 
        A distância do coscedo é dada pelo somatório da similaridade * a avalição dos usuários que avaliaram o
        item / multiplicação das raizes da soma dos hatings dos usuários. 
    
         */

        double covariancia = 0;
        double similaridade = 0;

        for (Hating ha : a.getTreinoPrecisaoRevocacao()) {
            for (Hating hb : b.getHatings()) {
                if (ha.getcodItem().equals(hb.getcodItem())) {
                    covariancia += (ha.getHating() * hb.getHating());
                }
            }
        }
        similaridade = covariancia / (Variancia(a.getTreinoPrecisaoRevocacao()) * Variancia(b.getHatings()));

        return similaridade;
    }

    public double SimilariadedeItem(ModeloDeRecomendacao a, ModeloDeRecomendacao b) {

        double covariancia = 0;
        double similaridade = 0;

        for (Hating ha : a.getHatings()) {
            for (Hating hb : b.getHatings()) {
                if (ha.getCodUsuario().equals(hb.getCodUsuario())) {
                    covariancia += (ha.getHating() * hb.getHating());
                }
            }
        }

        if ((Variancia(a.getHatings()) * Variancia(b.getHatings())) == 0) {
            return 0;
        }

        similaridade = covariancia / (Variancia(a.getHatings()) * Variancia(b.getHatings()));

        return similaridade;
    }

    private double Variancia(List<Hating> hating) {

        double variancia = 0;

        //Somatório dos itens ao quadrado
        for (Hating h : hating) {
            variancia += Math.pow(h.getHating(), 2);
        }

        //Raiz do somatório dos itens ao quadrado
        return Math.sqrt(variancia);
    }

    public double DefineHatingUsuario(List<Usuario> knn, Item item) {
        /*
        Calculo do Hating
        
        O hating dado para o usuário em um item que ele não avaliou é dado com base
        na soma das limilariades * peso dados pelos usuários mais próximos (knn) / soma da similidade dos usuários
        mais próximos ( knn )
    
         */
        double somaSimilaridades = 0;
        double similariadeXpeso = 0;
        boolean a = false;

        for (Usuario u : knn) {

            for (Hating h : u.getHatings()) {
                if (h.getcodItem().equals(item.getCodigo())) {
                    similariadeXpeso += (u.getSimilaridade() * h.getHating());
                }
            }
            somaSimilaridades += u.getSimilaridade();
        }

        if (somaSimilaridades == 0) {
            return 0;
        }

        return similariadeXpeso / somaSimilaridades;
    }

    public double DefineHatingItem(List<Item> knn, Usuario usuario) {
        /*
        Calculo do Hating
        
        O hating dado para o usuário em um item que ele não avaliou é dado com base
        na soma das limilariades * peso dados pelos usuários mais próximos (knn) / soma da similidade dos usuários
        mais próximos ( knn )
    
         */
        double somaSimilaridades = 0;
        double similariadeXpeso = 0;

        for (Item i : knn) {

            for (Hating h : i.getHatings()) {
                if (h.getCodUsuario().equals(usuario.getCodigo())) {
                    similariadeXpeso += i.getSimilaridade() * h.getHating();
                }
            }
            somaSimilaridades += i.getSimilaridade();
        }

        if (somaSimilaridades == 0) {
            return 0;
        }

        return similariadeXpeso / somaSimilaridades;
    }

    public List<Usuario> CalculaKNNUsuario(Usuario ub, List<Usuario> usuarios, int numNs, String item) {

        ArrayList knn = new ArrayList();

        for (Usuario u : usuarios) {

            if (!ub.getCodigo().equals(u.getCodigo())) {
                if (u.classificouItem(item)) {
                    u.setSimilidade(SimilariadedeUsuario(ub, u));
                    knn.add(u);
                }
            }
        }
        Collections.sort(knn);

        if (knn.size() > numNs) {
            return knn.subList(0, numNs);
        } else if (knn.size() <= numNs) {
            return knn.subList(0, knn.size());
        } else {
            return knn;
        }
    }

    public List<Item> CalculaKNNItens(Item ib, List<Item> itens, int numNs, String usuario) {

        ArrayList knn = new ArrayList();

        for (Item i : itens) {

            if (!i.getCodigo().equals(ib.getCodigo())) {

                if (i.foiClassificadoPor(usuario)) {

                    i.setSimilidade(SimilariadedeItem(ib, i));
                    knn.add(i);
                }
            }
        }

        Collections.sort(knn);

        if (knn.size() > numNs) {
            return knn.subList(0, numNs);
        } else if (knn.size() <= numNs) {
            return knn.subList(0, knn.size());
        } else {
            return knn;
        }

    }

    public List<Hating> calculaItensRelevantesUsuario(Usuario u, int diferencialMinimoRelevante) {
        /*
        Os relevantes definidos de acordo com os critérios:
        1) Não ter sido avaliado
        3) Ter Rating Maior ou igual ao Rating Mínimo
         */
        List<Hating> itensRelevantes = new ArrayList<>();

        for (Hating h : u.getHatingCalculado()) {

            for (Hating h2 : u.getTestePrecisaoRevocacao()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    u.addHatingsAvaliacao(h);
                    if (Math.abs(h.getHating() - h2.getHating()) <= diferencialMinimoRelevante) {
                        if (!itensRelevantes.contains(h)) {
                            itensRelevantes.add(h);

                        }
                    }
                }
            }
        }

        return itensRelevantes;
    }

    public List<Hating> calculaItensRelevantesUsuarioNaoPersonalisado(Usuario u, int diferencialMinimoRelevante) {
        /*
        Os relevantes definidos de acordo com os critérios:
        1) Não ter sido avaliado
        3) Ter Rating Maior ou igual ao Rating Mínimo
         */
        List<Hating> itensRelevantes = new ArrayList<>();

        for (Hating h : u.getHatingNaoPersonalisado()) {

            for (Hating h2 : u.getHatings()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    u.addHatingsAvaliacaoNaoPersonalisado(h);
                    if (Math.abs(h.getHating() - h2.getHating()) <= diferencialMinimoRelevante) {
                        if (!itensRelevantes.contains(h)) {
                            itensRelevantes.add(h);

                        }
                    }
                }
            }
        }

        return itensRelevantes;
    }

    public List<Hating> calculaItensRelevantesUsuarioConteudo(Usuario u, int diferencialMinimoRelevante) {
        /*
        Os relevantes definidos de acordo com os critérios:
        1) Não ter sido avaliado
        3) Ter Rating Maior ou igual ao Rating Mínimo
         */
        List<Hating> itensRelevantes = new ArrayList<>();

        for (Hating h : u.getHatingBaseadoEmConteudo()) {

            for (Hating h2 : u.getHatings()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    u.addHatingAvaliacaoConteudo(h);
                    if (Math.abs(h.getHating() - h2.getHating()) <= diferencialMinimoRelevante) {
                        if (!itensRelevantes.contains(h)) {
                            itensRelevantes.add(h);

                        }
                    }
                }
            }
        }

        return itensRelevantes;
    }

    public List<Hating> calculaUsuariosRelevantesItens(Item i, int diferencialMinimoRelevante) {

        List<Hating> itensRelevantes = new ArrayList<>();

        for (Hating h : i.getHatingCalculado()) {

            for (Hating h2 : i.getTestePrecisaoRevocacao()) {
                if (h2.getcodItem().equals(h.getcodItem())) {
                    i.addHatingsAvaliacao(h);
                    if (Math.abs(h.getHating() - h2.getHating()) <= diferencialMinimoRelevante) {
                        if (!itensRelevantes.contains(h)) {
                            itensRelevantes.add(h);

                        }
                    }
                }
            }
        }

        return itensRelevantes;
    }

    public void calculaPrecisaoRevocacaoItens(Item i, int diferencialMinimoRelevante) {

        List<Hating> relevantes = calculaUsuariosRelevantesItens(i, diferencialMinimoRelevante);

        int countRelevantes = relevantes.size();
        int countRelevantesRecuperados = 0;
        int countItensRecuperados = 0;

        double f1 = 0;
        double map = 0;
        double count = 0;

        for (Hating h : i.getHatingsAvaliacao()) {

            countItensRecuperados++;
            double relN = 0;

            if (relevantes.contains(h)) {
                countRelevantesRecuperados++;
                relN = 1;
            }

            if (countRelevantesRecuperados <= countRelevantes) {

                count++;
                double revocacao = (double) countRelevantesRecuperados / (double) countRelevantes;
                double precisao = (double) countRelevantesRecuperados / (double) countItensRecuperados;

                i.addPrecisaoRevocacao(new PrecisaoRevocacao(precisao, revocacao, h.getcodItem()));

                map += (precisao * relN) / relevantes.size();

                if ((precisao + revocacao) == 0) {
                    f1 += 0;
                } else {
                    f1 += (2 * (precisao * revocacao) / (precisao + revocacao));
                }

                double a = (precisao + revocacao) == 0 ? 0 : (2 * (precisao * revocacao) / (precisao + revocacao));

                if (countRelevantesRecuperados == countRelevantes) {
                    countRelevantesRecuperados++;
                }
            }

        }

        i.setMap(map / count);
        i.setF1(f1 / count);
    }

    public void calculaPrecisaoRevocacaoUsuario(Usuario u, int diferencialMinimoRelevante) {

        List<Hating> relevantes = calculaItensRelevantesUsuario(u, diferencialMinimoRelevante);

        int countRelevantes = relevantes.size();
        int countRelevantesRecuperados = 0;
        int countItensRecuperados = 0;

        double f1 = 0;
        double map = 0;
        double count = 0;

        for (Hating h : u.getHatingsAvaliacao()) {

            countItensRecuperados++;
            double relN = 0;

            if (relevantes.contains(h)) {
                countRelevantesRecuperados++;
                relN = 1;
            }

            if (countRelevantesRecuperados <= countRelevantes) {

                count++;
                double revocacao = (double) countRelevantesRecuperados / (double) countRelevantes;
                double precisao = (double) countRelevantesRecuperados / (double) countItensRecuperados;

                u.addPrecisaoRevocacao(new PrecisaoRevocacao(precisao, revocacao, h.getcodItem()));

                map += (precisao * relN) / relevantes.size();

                if ((precisao + revocacao) == 0) {
                    f1 += 0;
                } else {
                    f1 += (2 * (precisao * revocacao) / (precisao + revocacao));
                }

                double a = (precisao + revocacao) == 0 ? 0 : (2 * (precisao * revocacao) / (precisao + revocacao));

                if (countRelevantesRecuperados == countRelevantes) {
                    countRelevantesRecuperados++;
                }
            }

        }

        u.setMap(map / count);
        u.setF1(f1 / count);
    }

    public void calculaPrecisaoRevocacaoUsuarioNaoPersonalisado(Usuario u, int diferencialMinimoRelevante) {

        List<Hating> relevantes = calculaItensRelevantesUsuarioNaoPersonalisado(u, diferencialMinimoRelevante);

        int countRelevantes = relevantes.size();
        int countRelevantesRecuperados = 0;
        int countItensRecuperados = 0;

        double f1 = 0;
        double map = 0;
        double count = 0;

        for (Hating h : u.getHatingsAvaliacaoNaoPersonalisado()) {

            countItensRecuperados++;
            double relN = 0;

            if (relevantes.contains(h)) {
                countRelevantesRecuperados++;
                relN = 1;
            }

            if (countRelevantesRecuperados <= countRelevantes) {

                count++;
                double revocacao = (double) countRelevantesRecuperados / (double) countRelevantes;
                double precisao = (double) countRelevantesRecuperados / (double) countItensRecuperados;

                u.addPrecisaoRevocacaoNaoPersonalisado(new PrecisaoRevocacao(precisao, revocacao, h.getcodItem()));

                map += (precisao * relN) / relevantes.size();

                if ((precisao + revocacao) == 0) {
                    f1 += 0;
                } else {
                    f1 += (2 * (precisao * revocacao) / (precisao + revocacao));
                }

                double a = (precisao + revocacao) == 0 ? 0 : (2 * (precisao * revocacao) / (precisao + revocacao));

                if (countRelevantesRecuperados == countRelevantes) {
                    countRelevantesRecuperados++;
                }
            }

        }

        u.setNaoPersonalisadoMap(map / count);
        u.setNaoPersonalisadoF1(f1 / count);
    }

    public void calculaPrecisaoRevocacaoUsuarioConteudo(Usuario u, int diferencialMinimoRelevante) {

        List<Hating> relevantes = calculaItensRelevantesUsuarioConteudo(u, diferencialMinimoRelevante);

        int countRelevantes = relevantes.size();
        int countRelevantesRecuperados = 0;
        int countItensRecuperados = 0;

        double f1 = 0;
        double map = 0;
        double count = 0;

        for (Hating h : u.getHatingAvaliacaoConteudo()) {

            countItensRecuperados++;
            double relN = 0;

            if (relevantes.contains(h)) {
                countRelevantesRecuperados++;
                relN = 1;
            }

            if (countRelevantesRecuperados <= countRelevantes) {

                count++;
                double revocacao = (double) countRelevantesRecuperados / (double) countRelevantes;
                double precisao = (double) countRelevantesRecuperados / (double) countItensRecuperados;

                u.addPrecisaoRevocacaoConteudo(new PrecisaoRevocacao(precisao, revocacao, h.getcodItem()));

                map += (precisao * relN) / relevantes.size();

                if ((precisao + revocacao) == 0) {
                    f1 += 0;
                } else {
                    f1 += (2 * (precisao * revocacao) / (precisao + revocacao));
                }

                double a = (precisao + revocacao) == 0 ? 0 : (2 * (precisao * revocacao) / (precisao + revocacao));

                if (countRelevantesRecuperados == countRelevantes) {
                    countRelevantesRecuperados++;
                }
            }

        }

        u.setConteudoMap(map / count);
        u.setConteudoF1(f1 / count);
    }

    private double arredondar(double valor, int casas, int ceilOrFloor) {
        double arredondado = valor;
        arredondado *= (Math.pow(10, casas));
        if (ceilOrFloor == 0) {
            arredondado = Math.ceil(arredondado);
        } else {
            arredondado = Math.floor(arredondado);
        }
        arredondado /= (Math.pow(10, casas));
        return arredondado;
    }

    private int ContaRelevantes(List<Hating> hatingsAvaliacao, int nivelRelevante) {

        int relevantes = 0;

        for (Hating h : hatingsAvaliacao) {
            if (h.getHating() >= nivelRelevante) {
                relevantes++;
            }
        }
        return relevantes;

    }

    //##########################################  Métricas ####################################//
    public double CalculoMAEusuario(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Mean Absolute Error – MAE
        Bastante parecido com MSE, em vez de elevar a diferença entre a previsão do modelo, e o valor real,
        ao quadrado, ele toma o valor absoluto. Neste caso, em vez de atribuir um peso de acordo com a 
        magnitude da diferença, ele atribui o mesmo peso a todas as diferenças, de maneira linear.

        Se imaginarmos um exemplo simples, 
        onde temos apenas a variável que estamos tentando prever,  podemos ver um fato interessante
        que difere o MSE do MAE, e que devemos levar em conta ao decidir entre os dois: o valor que 
        minimizaria o primeiro erro seria a média,já no segundo caso, a mediana.

        FONTE:  http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/ 
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getcodItem().equals(pi.getcodItem())) {
                    piri += Math.abs(pi.getHating() - ri.getHating());
                }
            }

        }
        return piri / avaliados.size();
    }

    public double CalculoMAEItem(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Mean Absolute Error – MAE
        Bastante parecido com MSE, em vez de elevar a diferença entre a previsão do modelo, e o valor real,
        ao quadrado, ele toma o valor absoluto. Neste caso, em vez de atribuir um peso de acordo com a 
        magnitude da diferença, ele atribui o mesmo peso a todas as diferenças, de maneira linear.

        Se imaginarmos um exemplo simples, 
        onde temos apenas a variável que estamos tentando prever,  podemos ver um fato interessante
        que difere o MSE do MAE, e que devemos levar em conta ao decidir entre os dois: o valor que 
        minimizaria o primeiro erro seria a média,já no segundo caso, a mediana.

        FONTE:  http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/ 
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {

                if (ri.getCodUsuario().equals(pi.getCodUsuario())) {
                    piri += Math.abs(pi.getHating() - ri.getHating());
                }
            }

        }
        return piri / avaliados.size();
    }

    public double CalculoMSEusuario(List<Hating> avaliados, List< Hating> recomendados) {
        /*
            Mean Squared Error – MSE

            Talvez seja a mais utilizada, esta função calcula a média dos erros do modelo ao quadrado.
            Ou seja, diferenças menores têm menos importância, enquanto diferenças maiores recebem mais peso.
            Existe uma variação, que facilita a interpretação: o Root Mean Squared Error. 
            Ele é simplesmente a raiz quadrada do primeiro. Neste caso, o erro volta a ter as 
            unidades de medida originais da variável dependente.
            FONTE: http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/
         */

        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getcodItem().equals(pi.getcodItem())) {
                    piri += Math.pow((pi.getHating() - ri.getHating()), 2);
                }
            }

        }
        return piri / avaliados.size();
    }

    public double CalculoMSEItem(List<Hating> avaliados, List< Hating> recomendados) {
        /*
            Mean Squared Error – MSE

            Talvez seja a mais utilizada, esta função calcula a média dos erros do modelo ao quadrado.
            Ou seja, diferenças menores têm menos importância, enquanto diferenças maiores recebem mais peso.
            Existe uma variação, que facilita a interpretação: o Root Mean Squared Error. 
            Ele é simplesmente a raiz quadrada do primeiro. Neste caso, o erro volta a ter as 
            unidades de medida originais da variável dependente.
            FONTE: http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/
         */

        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getCodUsuario().equals(pi.getCodUsuario())) {
                    piri += Math.pow((pi.getHating() - ri.getHating()), 2);
                }
            }
        }
        return piri / avaliados.size();
    }

    public double CalculoMAPEusuario(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Mean Absolute Percentage Error – MAPE
        Este erro calcula a média percentual do desvio absoluto entre as previsões e a realidade. 
        É utilizado para avaliar sistemas de previsões de vendas e outros sistemas nos quais a diferença
        percentual seja mais interpretável, ou mais importante, do que os valores absolutos.
        FONTE: http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getcodItem().equals(pi.getcodItem())) {
                    piri += Math.abs(((pi.getHating() - ri.getHating()) / pi.getHating()));
                }
            }

        }
        return piri / avaliados.size();
    }

    public double CalculoMAPEItem(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Mean Absolute Percentage Error – MAPE
        Este erro calcula a média percentual do desvio absoluto entre as previsões e a realidade. 
        É utilizado para avaliar sistemas de previsões de vendas e outros sistemas nos quais a diferença
        percentual seja mais interpretável, ou mais importante, do que os valores absolutos.
        FONTE: http://mariofilho.com/as-metricas-mais-populares-para-avaliar-modelos-de-machine-learning/
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getCodUsuario().equals(pi.getCodUsuario())) {
                    piri += Math.abs(((pi.getHating() - ri.getHating()) / pi.getHating()));
                }
            }

        }
        return piri / avaliados.size();
    }

    public double CalculoRMSEusuario(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Root Mean Squared Error (RMSE)

        A raiz quadrada da média / média do quadrado de todos o erro.
        O uso de RMSE é muito comum e faz um excelente métrica de erro uso geral para previsões numéricas.
        Em comparação com o erro médio absoluto semelhante, RMSE amplifica e pune severamente grandes erros.
        FONTE:https://www.kaggle.com/wiki/RootMeanSquaredError
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getcodItem().equals(pi.getcodItem())) {
                    piri += Math.pow(pi.getHating() - ri.getHating(), 2);
                }
            }

        }
        return Math.sqrt(piri / avaliados.size());
    }

    public double CalculoRMSEItem(List<Hating> avaliados, List< Hating> recomendados) {
        /*
        Root Mean Squared Error (RMSE)

        A raiz quadrada da média / média do quadrado de todos o erro.
        O uso de RMSE é muito comum e faz um excelente métrica de erro uso geral para previsões numéricas.
        Em comparação com o erro médio absoluto semelhante, RMSE amplifica e pune severamente grandes erros.
        FONTE:https://www.kaggle.com/wiki/RootMeanSquaredError
         */
        double piri = 0;

        for (Hating ri : recomendados) {

            for (Hating pi : avaliados) {
                if (ri.getCodUsuario().equals(pi.getCodUsuario())) {
                    piri += Math.pow(pi.getHating() - ri.getHating(), 2);
                }
            }

        }
        return Math.sqrt(piri / avaliados.size());
    }

    public void CalculaTFIDF(List<Palavra> termos, List<Item> itens) {
        /*Faz o calculo de TFIDF para as palavras de acorodo com todos os documentos, de 
        acordo com a formula:

        w(t,d) = f(t)t,d × f(id)t 

        •Onde o f(t)t.d  representa O cálculo dos pesos ,
        que é feito inicialmente deﬁnindo-se a frequência de um termo (do inglês term frequency-tf) 
        como sendo o número de vezes que um determinado termo t aparece no texto de um documento d.

        •f(id)t representa o IDF do termo na base de documentos

        Refência Slide Camilo
         */
        CalculaIDF(termos, itens);

        for (Item item : itens) {

            int maiorFrequenca = item.definePlavraComMaiorFrequencia();
            for (Palavra termo : termos) {

                float TF = (float) item.getFrequenciaNoDocumento(termo.getPalavra()) / (float) maiorFrequenca;
                float TFIDF = TF * termo.getIdf();

                item.addTfIdf(new TfIdf(termo.getPalavra(), TFIDF));

            }

        }
    }

    public void CalculaIDF(List<Palavra> termos, List<Item> itens) {
        /*Faz o calculo de IDF para as palavras de acorodo com a lormula:
        f(id)t = ln(N/nt)

        • onde N é o número de documentos na base de documentos e nt é o número 
        de documentos que contém o termo t.
        • Quanto menor o número de documentos que contém um determinado termo, 
        maior o idf desse termo. Se todos os documentos da base de documentos 
        contiverem um determinado termo, o fid desse termo será igual a um (1).

        Refência Slide Camilo
         */
        for (Palavra palavra : termos) {

            int cont = 0;

            for (Item item : itens) {
                if (item.existePalavra(palavra.getPalavra())) {
                    cont++;
                }
            }
            float idf = 0;
            if (cont > 0) {
                idf = (float) ((float) Math.log((float) itens.size() / (float) cont) / Math.log(2));
            }

            palavra.setIdf(idf);
        }
    }

    public void CalculaRocchioMatriz(Usuario u, List<Item> itens, List<Palavra> termos) {

        double soma = 0;

        for (Palavra t : termos) {

            for (Item i : itens) {
                if (i.existePalavra(t.getPalavra()) && UsuarioAvaliouItem(u.getHatings(), i.getCodigo())) {
                    soma += i.getTFIDF(t.getPalavra()) * (double) u.getHatingItem(i.getCodigo());
                }
            }

            u.addTfIdfRochio(new TfIdf(t.getPalavra(), soma / u.getHatings().size()));
            soma = 0;
        }

    }

    public void DefineHatingConteudo(Usuario u, List<Item> itens) {

        double somaRocchoxTfIdf = 0;
        double somaRocchioQuadrado = 0;
        double somaTFIDFQuadrado = 0;
        double hating = 0;

        int cont = 0;
        for (Item i : itens) {
            double timeini = System.currentTimeMillis();
            System.out.println("Defindo Hating para o item" + cont++);
            for (TfIdf tfidf : i.getTfIdf()) {

                for (TfIdf tfidfUsuario : u.getRocchioMatriz()) {
                    if (tfidfUsuario.getPalavra().equals(tfidf.getPalavra())) {
                        somaRocchoxTfIdf += tfidf.getTfIdf() * u.getHocchioItem(tfidf.getPalavra());
                        somaTFIDFQuadrado += Math.pow(tfidf.getTfIdf(), 2);
                        somaRocchioQuadrado += Math.pow(u.getHocchioItem(tfidf.getPalavra()), 2);
                    }
                }
            }

            if ((Math.sqrt(somaRocchioQuadrado) * Math.sqrt(somaTFIDFQuadrado)) == 0) {
                u.addHatingBaseadoEmConteudo(new Hating(u.getCodigo(), i.getCodigo(), 0));
            } else {
                hating = somaRocchoxTfIdf / (Math.sqrt(somaRocchioQuadrado) * Math.sqrt(somaTFIDFQuadrado));
                u.addHatingBaseadoEmConteudo(new Hating(u.getCodigo(), i.getCodigo(), hating * 5));
            }

            somaRocchoxTfIdf = 0;
            somaRocchioQuadrado = 0;
            somaTFIDFQuadrado = 0;
            hating = 0;
            System.out.println("Tempo de Execução " + ((double) System.currentTimeMillis() - timeini) + " MiliSegundos ");

        }

    }

    public double RankingHatingNaoPersonalizado(Item item) {
        /*
        O hanking não personalizado gerá a recomendação com base na médias das avaliações
        dos itens    
         */
        double soma = 0;
        for (Hating h : item.getHatings()) {
            soma += h.getHating();
        }
        return soma / item.getHatings().size();
    }

    private boolean UsuarioAvaliouItem(List<Hating> hatings, String codigoItem) {

        for (Hating h : hatings) {
            if (h.getcodItem().equals(codigoItem)) {
                return true;
            }
        }
        return false;
    }

    public List<Palavra> CriarVocabulario(List<Item> itens) {

        List<Palavra> vocabulario = new ArrayList<>();

        for (Item i : itens) {

            for (String s : i.getTermos()) {

                if (!vocabulario.contains(s)) {
                    vocabulario.add(new Palavra(s));
                }
            }

        }
        return vocabulario;
    }

}
